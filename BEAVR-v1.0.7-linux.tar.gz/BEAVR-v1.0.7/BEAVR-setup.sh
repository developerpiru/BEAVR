#!/bin/bash

echo "Updating repositories..."
sudo apt-get update -y
#install required libraries
echo "Installing required linux packages..."
sudo apt-get install pandoc pandoc-citeproc libcurl4-gnutls-dev libcairo2-dev libxt-dev libssl-dev libssh2-1-dev libjpeg62-turbo-dev libpng-dev libtiff-dev -y
#install latest r-base
echo "Getting latest r-base..."
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E298A3A825C0D65DFD57CBB651716619E084DAB9
sudo add-apt-repository 'deb https://cloud.r-project.org/bin/linux/ubuntu bionic-cran35/'
sudo apt-get update -y
echo "Installing r-base..."
sudo apt install r-base -y
#install R packages using Rscript
echo "Installing required R packages..."
Rscript installpkgs.R
#copy BEAVR folder to /usr/local/bin/BEAVR
cp -r BEAVR /usr/local/bin/
sudo chmod -R +x usr/local/bin/BEAVR