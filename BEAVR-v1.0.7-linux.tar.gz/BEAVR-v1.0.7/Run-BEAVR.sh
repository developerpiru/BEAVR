#!/bin/bash

#run Rscript that starts BEAVR
echo "Starting BEAVR..."
Rscript /usr/local/bin/BEAVR/start.R