#start BEAVR
library(shiny)
library(shinydashboard)

setwd("/usr/local/bin/BEAVR/")

runApp(port=3838)
