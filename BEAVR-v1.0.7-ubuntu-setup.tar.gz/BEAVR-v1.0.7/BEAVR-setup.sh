#!/bin/bash

echo "Updating repositories..."
sudo apt-get update -y
#install required libraries
echo "Installing required linux packages..."
sudo apt-get install pandoc pandoc-citeproc libcurl4-openssl-dev libxml2-dev libcairo2-dev libxt-dev libssl-dev libssh2-1-dev libjpeg-turbo8-dev libpng-dev libtiff-dev -y
#install latest r-base
echo "Searching for latest r-base..."
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E298A3A825C0D65DFD57CBB651716619E084DAB9
sudo add-apt-repository 'deb https://cloud.r-project.org/bin/linux/ubuntu bionic-cran35/'
sudo apt-get update -y
echo "Installing r-base..."
sudo apt install r-base -y
#install R packages using Rscript
echo "Installing required R packages..."
sudo Rscript installpkgs.R
#copy BEAVR folder to /usr/local/bin/BEAVR
echo "Copying BEAVR files..."
sudo cp -r BEAVR /usr/local/bin/
sudo chmod -R +x /usr/local/bin/BEAVR
echo "Adding BEAVR to PATH..."
export PATH=$PATH:/usr/local/bin/BEAVR
source ~/.profile
echo "Setup has finished"
echo "Please enter the command 'BEAVR' to  start BEAVR"

