#!/bin/bash

echo ""
echo "Loading latest BEAVR container image..."
echo ""
docker run -ti -p 3838:3838 pirunthan/beavr:latest

