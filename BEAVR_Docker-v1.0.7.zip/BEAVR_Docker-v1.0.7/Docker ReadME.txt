# working docker container for BEAVR

# build container 
docker build -t beavr .

# run container
docker run -ti -p 3838:3838 beavr