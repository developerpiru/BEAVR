﻿#requires -RunAsAdministrator 

#build BEAVR container
docker build -t beavr .