﻿#requires -RunAsAdministrator 

# start BEAVR container on port 3838
docker run -ti -p 3838:3838 beavr


#$ExtPort=$args[0]

#set-variable -name BEAVR_VERSION -value "1.0.1"

#echo "BEAVR " + $BEAVR_VERSION

#$ExtPort = Read-Host -Prompt 'Enter an external port number to use for BEAVR...'

#$prefix = 'docker.exe', 'run', '-ti', '-p ', $ExtPort
#$prefix = 'docker.exe', 'run', '-ti', 'beavr'
#$suffix = ':3838 beavr'

#& $prefix $suffix