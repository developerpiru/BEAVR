#!/bin/bash

# This script will install the latest verson of R on Ubuntu
# and install all of the required packages for BEAVR
# Script author: https://github.com/developerpiru

echo ""
echo "=========================================================================="
echo "This script will install the latest verson of R on Ubuntu"
echo "and install all of the required packages for BEAVR"
echo "Script author: https://github.com/developerpiru"
echo "=========================================================================="

echo ""
echo "Updating repositories..."
echo ""
sudo apt-get update -y

#install required libraries
echo ""
echo "Installing required linux packages..."
echo ""
sudo apt-get install pandoc pandoc-citeproc libcurl4-openssl-dev libxml2-dev libcairo2-dev libxt-dev libssl-dev libssh2-1-dev libjpeg-turbo8-dev libpng-dev libtiff-dev -y

#install latest r-base
echo ""
echo "Searching for latest r-base..."
echo ""
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E298A3A825C0D65DFD57CBB651716619E084DAB9
sudo add-apt-repository 'deb https://cloud.r-project.org/bin/linux/ubuntu bionic-cran35/'
sudo apt-get update -y

echo ""
echo "Installing R..."
echo ""
sudo apt install r-base -y

#install R packages using Rscript

echo ""
echo "Installing required R packages..."
echo ""
sudo Rscript installpkgs.R

echo ""
echo "Setup has finished"
