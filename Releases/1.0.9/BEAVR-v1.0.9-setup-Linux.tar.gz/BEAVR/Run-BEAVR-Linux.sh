#!/bin/bash

#run Rscript that starts BEAVR
echo ""
echo "Starting BEAVR..."
echo ""
Rscript start.R


