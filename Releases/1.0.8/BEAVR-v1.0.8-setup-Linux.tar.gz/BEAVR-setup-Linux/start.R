#start BEAVR
library(shiny)
library(shinydashboard)

runApp(port=3838)
